
function createTag(){
	$("#myModal").modal('show');
}


function showMsg(id, msg,warn){
	$("#"+id).html(msg);
	if(warn){
		alert("warn")
		$("#"+id).removeClass('alert-success');
		$("#"+id).addClass('alert-danger');
	}else{
		$("#"+id).removeClass('alert-danger')
        $("#"+id).addClass('alert-success');
	}
	
}
function clearMsg(id){
	$("#"+id).html();
}
function saveTag(){
	var tag_names = $('#modal_tag_names').val();
	var tags = tag_names.split(",");
	var l = tags.length;
	for(i = 0 ; i < l; i++){
		if(!is_alphanum(tags[i])){
			showMsg('success','Invalid data entered for Tag',1);
			return false;
		}
	}
	$('#tag_names').val(tag_names);
	$('#tag_box').html(tag_names);
	$("#myModal").modal('hide');
}
function is_alphanum(str){
	return /^[a-zA-Z0-9\s]+$/.test(str) ;
}
function is_allowedchars(str){
	//can add more chars
	return /^[a-zA-Z0-9_()\s]+$/.test(str) ;
}
function saveTodoList(){
	var msg='';
	//error conditions and checks can be refined (normally i would use jquery validation plugin)
	var error = false;
	if(!is_allowedchars($('#title').val())){
		msg = 'Please enter valid characters for title';
		error = true;
	}
	if(!is_allowedchars($('#description').val())){
		msg += '\nPlease enter valid characters for description';
		
		error = true;
	}
	if($('#due_date').val() == ''){
		msg += '\nPlease select a due date';
		error = true;
	}
	if(!is_alphanum($('#author').val())){
		msg += '\nPlease enter valid characters for author';
		error = true;
	}
	
	if(error){
		alert( msg);
		return false;
	}
        $.ajax({
        type: "POST",
    url: "/todo_list/todolist",
    data: $('#todo_list_form').serialize(),
    dataType:'json',
        success: function(res){
               if(res.msg == 'OK'){
            	   alert("Successfully saved the to do list");
            	   window.location.replace("/todo_list/all");
               }else{
                alert(res.msg);
               }
            },
    error: function(){
        alert("Failed to save the to do list");
        }
          });
}
