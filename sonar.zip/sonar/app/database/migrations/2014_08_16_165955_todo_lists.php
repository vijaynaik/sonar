<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TodoLists extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('todo_lists', function($table)
        {
            $table->increments('todo_lists_id');
            $table->string('title');
            $table->string('description');
            $table->string('due_date');
            $table->string('author');
            $table->index('title');
        });
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('todo_lists');
	}

}
