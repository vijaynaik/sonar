<?php
/*
 * Created on Aug 15, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
class TodoListController extends BaseController
{
	protected $layout = 'layout';
	
    public function getAll()
    {
    	$data['title'] = "To Do List";
    					
		$todolists = TodoListsModel::join('Tags', 'todo_lists.todo_lists_id', '=', 'tags.todo_lists_id')->get();
		//dd(DB::getQueryLog());
		//var_dump($todolists);
		foreach($todolists as $list){
			$final_list[$list->todo_lists_id]['row'] = $list;
			$final_list[$list->todo_lists_id]['tag'][] = $list->tag_name;  
		}
        $this->layout->content = View::make('lists')->with(array('title' =>'Test', 'todolists' => $final_list));
    }

    
	public function postTodolist()
    {
    	//These validation rules shud be in a custom validator class but for now i am using them here
    	Validator::extend('is_title', function($field,$value,$parameters){
		 return preg_match('/[a-zA-Z0-9\s]/',$value);
		});
		
		Validator::extend('is_allowed', function($field,$value,$parameters){
		 return preg_match('/[a-zA-Z0-9_()\s]/',$value);
		});
    	$todolist = new TodoListsModel();
    	$data = Input::all();
    	//var_dump($data);
    	//exit;
		$rules = ['title' => 'required|is_title','description' => 'required|is_allowed', 'due_date' => 'required', 'author' => 'required|is_allowed'];
		//print_r($data);
		$validator = Validator::make($data,$rules);
		if(!$validator->passes()){
			echo json_encode(array('msg' => 'Invalid data entered. Please verify!'));
			exit;
		}
		$todolist->title = $data['title'];
		$todolist->description = $data['description'];
		$todolist->author = $data['author'];
		$todolist->due_date = $data['due_date'];
		$todolist->timestamps = false;
		$todolist->save();
		if($todolist->id)
		{
			//Now check if there r any tags entered for this list
			if(!empty($data['tag_names'])){
				$tag_names = explode(",",$data['tag_names']);
				$rules = ['tag_name' => 'is_title'];
				$err = false;
				$processed_tag = array();
				foreach($tag_names as $tag){
					//Verify if tag is valid
					$l_tag = strtolower($tag);
					if(!empty($processed_tag[$l_tag])) continue;
					$processed_tag[$l_tag] =1;
					$data=array('tag_name' => $tag);
					$validator = Validator::make($data,$rules);
					if(!$validator->passes()){
						$err = true;
					}else{
						//Create an entry in tags table
						$insert_arr[] = array('todo_lists_id' => $todolist->id, 'tag_name' => $tag);
					}
				}
				if($err){
					echo json_encode(array('msg' => 'Invalid tag entered')) ;
				}else{
					DB::table('tags')->insert($insert_arr);
				}
			}
		 	echo json_encode(array('msg' => 'OK')) ;
		}
		else
		{
			echo json_encode(array('msg' => 'Failed to save the Todo List'));
		}
 	    exit;
	}
}