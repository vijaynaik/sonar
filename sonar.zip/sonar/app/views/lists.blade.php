@extends('layout')
@section('content')
    <div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand">SonarDesign</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a href="/todo_list/all">To Do List</a></li>
          </ul>
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
          <h2 class="sub-header">To Do List</h2>
          <div class="table-responsive">
          <form id="todo_list_form">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Description</th>
                  <th>Due Date</th>
                  <th>Author</th>
                  <th>Tag</th>
                </tr>
              </thead>
              <tbody>
              
                <tr>
                  <td><input type="text" placeholder="Title" name="title" id="title" size="10"></td>
                  <td><input type="text" placeholder="Description" name="description" id="description" size="10"></td>
                  <td><input type="text" placeholder="Due Date" name="due_date" id="due_date" size="10" class='datepicker'></td>
                  <td><input type="text" placeholder="Author" name="author" id="author" size="10"></td>
                  <td><a href="javascript:void(0)" onclick="createTag()">Add Tags</a><input type="hidden" id="tag_names" name="tag_names">
                  <div id="tag_box"></div>
                  <!--
                  <div class="dropdown">
					  <select id='tagslist_id' name='tagslist_id' class="form-control" onChange='createTag()'>
					  <option value=''>Select Tag</option>
					  
						<option value='newTag'>Create New Tag</option>
					</select>
					</div>
					-->
				  </td>
                </tr>
                <tr>
                  <td colspan=5 align="center"><button type="button" class="btn btn-primary" onclick='saveTodoList()'>Save</button></td>
                </tr>
                @foreach($todolists as $todolist)
                <tr><td>{{$todolist['row']->title}}<td>{{$todolist['row']->description}}<td>{{$todolist['row']->due_date}}<td>{{$todolist['row']->author}}<td>{{implode(",", $todolist['tag'])}}</td></tr>
                @endforeach
                </tbody>
            </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  
    <div id="myModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Add Tag</h4>
                </div>
                <div class="modal-body">
                <form id='tag'>
                    <table class="table table-striped">
              <thead>
                <tr>
                  <th>Tag</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><textarea name="modal_tag_names" id="modal_tag_names" placeholder="comma separated tags" rows=2 cols=10></textarea></td>
                </tr>
              </tbody>
            </table>
            </form>
                </div>
                <div id='success' class="alert" role="alert"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick='saveTag()'>Add Tag</button>
                </div>
            </div>
        </div>
    </div>
       
    {{ HTML::script('packages/js/functions.js') }}
    
    @stop
   