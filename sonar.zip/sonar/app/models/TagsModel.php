<?php
/*
 * Created on Aug 16, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;
 
class TagsModel extends Eloquent
{
    protected $table = 'tags';
   
    public function TodoLists() {
        return $this->belongsTo('TodoListsModel');
    }
}
?>
