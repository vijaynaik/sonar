<?php
/*
 * Created on Aug 15, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;
 
class TodoListsModel extends Eloquent
{
    protected $table = 'todo_lists';
    public function Tags() {
        return $this->hasMany('TagsModel','todo_lists_id');
    }
}
?>
